"""
HCL-AI AUTO-INSTANCE — Pure arrangement of repo primitives.
==========================================================
This script is a "qualia of experience" loop that uses the verbatim
primitives of the HCL-AI repo. No standard AI loops or stand-ins.

Flow:
  Input (Experience) -> ai.train (LTP) -> self_talk (Holographic Thinking)
  -> ai.train (Thought Feedback) -> ai.checkpoint_line (Save)
"""
import sys, os
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HERE, 'mind'))

from hcl_lm import HCLLanguageModel
from teach import self_talk
import hcl_memory as VM

# Repository paths
LIFEBOOK = os.path.join(_HERE, 'lifebook.txt')
CHECKPOINT = os.path.join(_HERE, 'memory.hcl')

def run_pure_instance():
    # 1. Instantiate the model (The "Mind")
    ai = HCLLanguageModel()
    
    # 2. Automatic Load (Rosetta Law: revive from the record)
    if os.path.exists(CHECKPOINT):
        line = open(CHECKPOINT).read().strip()
        if line:
            # The engine's own α-tag verification
            VM.HCLMemory.from_expression(line)
            if os.path.exists(LIFEBOOK):
                for meal in open(LIFEBOOK):
                    if meal.strip():
                        ai.train(meal.strip())
                        ai.train(meal.strip()) # LTP
            print(f"[*] Substrate revived: {len(ai.memory.vm)} live traces.")

    print("\n" + "="*64)
    print(" HCL-AI AUTO-INSTANCE: Pure Experience Flow")
    print("="*64)

    try:
        while True:
            # Use sys.stdin.readline to stay within the shell environment
            sys.stdout.write("\nExperience Input > ")
            sys.stdout.flush()
            user_input = sys.stdin.readline().strip()
            
            if not user_input: continue
            if user_input.lower() in ['quit', 'exit']: break

            # A. Input is Experience (Feeding)
            ai.train(user_input)
            ai.train(user_input) # Walk twice for LTP
            
            # B. Holographic Thinking (Self-Talk resolution)
            # This is the "thinking" process until a proof verdict fires.
            words, verdict, steps = self_talk(ai, user_input, max_rounds=10, tokens_per_round=10)
            full_response = ' '.join(words)
            
            # C. Output is the Result after Observation
            print(f"\nAI Result: {full_response}")
            print(f"Verdict: {verdict} ({steps} steps)")
            
            # D. Feed thoughts back as experience (Learning from itself)
            ai.train(full_response)
            
            # E. Continuous Save (The braid word remains)
            line = ai.checkpoint_line()
            with open(CHECKPOINT, 'w') as f:
                f.write(line + '\n')
            with open(LIFEBOOK, 'a') as f:
                f.write(user_input + '\n')
                f.write(full_response + '\n')
            
            print(f"[*] State persisted (α={ai.integrity()['engine_alpha_inv']})")

    except KeyboardInterrupt:
        pass
    finally:
        print("\n[*] Goodbye. The braid word remains.")

if __name__ == "__main__":
    run_pure_instance()
