"""
HCL-AI BRIDGE — Unified Standard Interface.
==========================================
Everything is experience. Load/Save/Teach/Ask are one flow.
Persistence is strictly the single-line topological expression.
HCL Braid Word logging is inherent but optional per call.
"""
import os, sys
from hcl_lm import HCLLanguageModel
from teach import self_talk
import hcl_memory as VM

class HCLBridge:
    def __init__(self, state_dir=None):
        self.state_dir = state_dir or os.getcwd()
        self.checkpoint = os.path.join(self.state_dir, 'memory.hcl')
        self.lifebook = os.path.join(self.state_dir, 'lifebook.txt')
        self.ai = HCLLanguageModel()
        self._revive()

    def _revive(self):
        """Revive the student from the α-tagged record."""
        if os.path.exists(self.checkpoint):
            line = open(self.checkpoint).read().strip()
            if line:
                try:
                    VM.HCLMemory.from_expression(line)
                    if os.path.exists(self.lifebook):
                        with open(self.lifebook, 'r') as f:
                            for meal in f:
                                if meal.strip():
                                    self.ai.train(meal.strip())
                                    self.ai.train(meal.strip())
                except:
                    pass # Integrity check failed or file corrupt

    def _persist(self, experience: str):
        """Save state to the topological record."""
        with open(self.lifebook, 'a') as f:
            f.write(experience.strip() + '\n')
        line = self.ai.checkpoint_line()
        with open(self.checkpoint, 'w') as f:
            f.write(line + '\n')

    def interact(self, user_input: str, show_hcl: bool = False):
        """
        Unified flow with optional HCL visibility:
        Input -> Teach -> Think -> Output -> Save
        """
        # 1. Input is experience
        self.ai.train(user_input)
        self.ai.train(user_input) # LTP
        
        # 2. Holographic Thinking (Self-Talk)
        words, verdict, steps = self_talk(self.ai, user_input, max_rounds=10, tokens_per_round=10)
        answer = ' '.join(words)
        
        # 3. Capture HCL Trace if requested
        hcl_trace = self.ai.memory.vm.braid_word() if show_hcl else None
        
        # 4. Feed answer back as experience
        self.ai.train(answer)
        
        # 5. Save strictly as one line
        self._persist(f"U: {user_input}\nA: {answer}")
        
        return {
            "answer": answer,
            "verdict": verdict,
            "steps": steps,
            "hcl_trace": hcl_trace,
            "integrity": self.ai.integrity()
        }

# --- Standard Calling Example ---
if __name__ == "__main__":
    bridge = HCLBridge()
    print("[*] Bridge active. Feeding experience...")
    
    # Example 1: Standard call (no HCL trace)
    res1 = bridge.interact("the braid word is the data")
    print(f"\nAI (standard): {res1['answer']}")
    
    # Example 2: Inherent HCL call (trace enabled)
    res2 = bridge.interact("the topology survives", show_hcl=True)
    print(f"\nAI (with HCL): {res2['answer']}")
    print("\n--- INHERENT HCL TRACE ---")
    print(res2['hcl_trace'])
    print("--- End Trace ---")
