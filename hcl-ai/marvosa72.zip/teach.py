"""
TEACH/GROW — Flattened for bridge connectivity.
"""
import sys, os
_HERE = os.path.dirname(os.path.abspath(__file__))

from hcl_lm import HCLLanguageModel, _MAX_W
from juj import braid_invariants, bytes_to_braid, mcl_eps, SCALE, _fmul, _fdiv

def state_energy(words):
    ctx = ' '.join(words[-_MAX_W:])
    return braid_invariants(bytes_to_braid(ctx.encode()))['spectrum'].amp

def mcl_verdict(start_words, events, w_final, states, H):
    if not events:
        return 'TERMINATED — no attractor instantiates'
    words = list(start_words)
    if not states:
        states.append(tuple(words[-_MAX_W:]))
        H.append(state_energy(words))
    for e in events:
        words.append(e['key'].rsplit('>', 1)[1])
        tail = tuple(words[-_MAX_W:])
        if tail in states:
            return f'BRAID CLOSED — ground cycle reached'
        states.append(tail)
        H.append(state_energy(words))
    N      = len(H)
    mean_H = sum(H) // N
    mean_H2 = sum(_fmul(h, h) for h in H) // N
    if mean_H == 0:
        return 'TERMINATED — zero-energy trajectory'
    var    = mean_H2 - _fmul(mean_H, mean_H)
    I_w    = _fdiv(max(var, 0), _fmul(mean_H, mean_H))
    eps    = mcl_eps(max(w_final, 1))
    if I_w < eps:
        return f'MCL COLLAPSE — I_w={I_w/SCALE:.6f} < eps_w={eps/SCALE:.6f}'
    return None

def self_talk(ai, seed, max_rounds=4, tokens_per_round=10):
    words = seed.split()
    total_steps = 0
    states, H = [], []
    for r in range(max_rounds):
        out = ai.generate(' '.join(words), max_tokens=tokens_per_round)
        start = list(words)
        total_steps += len(out['events'])
        verdict = mcl_verdict(start, out['events'], ai.w, states, H)
        spoken  = ai.speak(out['text'])
        words   = spoken['expanded'].split()
        if verdict:
            return words, verdict, total_steps
        ai.experience_cycle()
    return words, 'still descending', total_steps
