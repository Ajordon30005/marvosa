"""
HCL-LM — Flattened for bridge connectivity.
"""
import sys, os
_HERE = os.path.dirname(os.path.abspath(__file__))

# ── parts taken verbatim from the engines ────────
import hcl_memory as VM
from hcl_memory import FBit, hcl_comp, _fdiv, SCALE as MSCALE
from hcl_engine import HCL
import juj
from juj import (bytes_to_hvp, hvp_to_bytes, bytes_to_braid,
                 braid_invariants, mcl_eps, GAMMA, SCALE as PSCALE,
                 ALPHA_INV as P_ALPHA_INV)
from living_memory import LivingMemory
import hcl_engine
from hcl_engine import HCLEquation

_SEP   = '\x1f'
_MAX_W = 5

class HCLLanguageModel:
    def __init__(self):
        self.memory = LivingMemory()
        self.mind   = HCLEquation()
        self.w      = 1

    def perceive(self, text: str) -> dict:
        return bytes_to_hvp(text.encode())

    def train(self, corpus: str) -> dict:
        words = corpus.split()
        seen  = {t['content_key'] for t in self.memory.vm._terms}
        stored = reinforced = 0
        for i in range(1, len(words)):
            nxt = words[i]
            for d in range(1, min(_MAX_W, i) + 1):
                ctx = ' '.join(words[i - d:i])
                key = f'w{d}|{ctx}>{nxt}'
                if key in seen:
                    self._ltp(key)
                    self._psi_dirty = True
                    reinforced += 1
                else:
                    self.memory.store(key, ctx + _SEP + nxt)
                    seen.add(key)
                    stored += 1
        return {'stored': stored, 'reinforced': reinforced,
                'signature': self.memory.signature()}

    def experience_cycle(self) -> int:
        return self.memory.cycle()

    def _tune_w(self, context_words: list) -> None:
        ceiling = max(min(len(context_words), _MAX_W), 1)
        self.w  = max(min(self.w, ceiling), 1)
        ctx = ' '.join(context_words[-_MAX_W:])
        inv = braid_invariants(bytes_to_braid(ctx.encode()))
        I_w = inv['stability']
        while self.w < ceiling:
            if I_w < mcl_eps(self.w):
                break
            self.w += 1

    def _collapse(self, context_words: list):
        for d in range(min(self.w, len(context_words)), 0, -1):
            ctx    = ' '.join(context_words[-d:])
            prefix = f'w{d}|{ctx}>'
            cands  = [t for t in self.memory.vm._terms
                      if t['content_key'].startswith(prefix)]
            if not cands:
                continue
            ranked = VM.recall_from_store(cands, ctx, k=1)
            if ranked:
                best_key = ranked[0][0]
                full = self.memory.regenerate(best_key)
                continuation = full.split(_SEP, 1)[1]
                return best_key, continuation
        return None, None

    def _ltp(self, key) -> None:
        idx = getattr(self, '_term_index', None)
        if idx is None or len(idx) != len(self.memory.vm._terms):
            idx = {t['content_key']: t for t in self.memory.vm._terms}
            self._term_index = idx
        t = idx.get(key)
        if t is not None:
            f = FBit(t['phase_frac'], t['amp'])
            g = hcl_comp(f, f)
            t['phase_frac'], t['amp'] = g.phase_frac, g.amp
        self.memory.accessed.add(key)

    def _renormalize(self, budget: int) -> None:
        terms = self.memory.vm._terms
        if not terms:
            return
        mean = sum(t['amp'] for t in terms) // len(terms)
        ceiling = mean * 8
        if ceiling <= 0:
            return
        for t in terms:
            if t['amp'] > ceiling:
                ratio = _fdiv(ceiling, t['amp'])
                f = HCL.SHIFT(FBit(t['phase_frac'], t['amp']), ratio)
                t['amp'] = f.amp

    def generate(self, prompt: str, max_tokens: int = 20) -> dict:
        words  = prompt.split()
        self.w = max(min(len(words), _MAX_W), 1)
        budget = sum(t['amp'] for t in self.memory.vm._terms)
        events = []
        for _ in range(max_tokens):
            self._tune_w(words)
            key, nxt = self._collapse(words)
            if key is None:
                break
            self._ltp(key)
            events.append({'w': self.w, 'key': key})
            words.append(nxt)
        if events:
            self._renormalize(budget)
            self._psi_dirty = True
        text = ' '.join(words)
        return {'text': text, 'events': events}

    def reason(self, equation: str, **variables):
        return self.mind.solve(equation, **variables)

    def speak(self, text: str) -> dict:
        sig      = bytes_to_hvp(text.encode())
        expanded = hvp_to_bytes(sig, verify=True).decode()
        return {'hvp_params': {k: v for k, v in sig['params'].items()},
                'braid_len': len(sig['braid']),
                'expanded': expanded,
                'bit_perfect': expanded == text}

    def _ensure_psi(self) -> None:
        if getattr(self, '_psi_dirty', False):
            self.memory._recompose()
            self._psi_dirty = False

    def signature(self) -> dict:
        self._ensure_psi()
        return self.memory.signature()

    def checkpoint_line(self) -> str:
        self._ensure_psi()
        return self.memory.vm.to_expression()

    def integrity(self) -> dict:
        self._ensure_psi()
        mem = self.memory.integrity()
        eng = hcl_engine.ALPHA_INV / hcl_engine.SCALE
        return {**mem,
                'engine_alpha_inv': eng,
                'intact': mem['intact'] and abs(eng - 137) < 1}
